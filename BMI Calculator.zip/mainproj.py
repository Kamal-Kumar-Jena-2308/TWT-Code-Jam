from tkinter import *
from tkinter import messagebox
import os
tk=Tk()
tk.geometry("500x500")
tk.title("BMI Calculator -By Kamal")
tk.resizable(False,False)
def bmi():
    b1.config(state='disabled')
    b5.config(state='disabled')
    b4.config(state='disabled')
    bmiw=Toplevel()
    bmiw.title("BMI Calculator -By Kamal")
    bmiw.geometry("300x250")
    bmiw.resizable(False,False)
    weight=StringVar()
    hi=StringVar()
    hcm=StringVar()
    weights=Label(bmiw,text="Weight: ", font='algerian').place(x=30,y=20)
    hcms=Label(bmiw,text="Height: ", font='Algerian').place(x=30, y=75)
    weights1=Label(bmiw,text="Kg", font='algerian').place(x=185,y=20)
    hcms1=Label(bmiw,text="Cm", font='Algerian').place(x=185, y=75)
    wrd1 = Entry(bmiw, font="lucida 12 bold", bg="#B9D9EB", borderwidth=3, textvariable=weight)
    wrd3 = Entry(bmiw, font="lucida 12 bold", bg="#B9D9EB", borderwidth=3, textvariable=hcm)
    # wrd3.place_configure(x=100,y=10,height=50,width=150)
    wrd1.place_configure(x=130,y=10,height=50,width=50)
    wrd3.place_configure(x=130,y=65,height=50,width=50)
    def disable_event():
        pass
    bmiw.protocol("WM_DELETE_WINDOW", disable_event)
    def delete():
        bmiw.destroy()
        b1.config(state="normal")
        b4.config(state="normal")
        b5.config(state="normal")
    def clear():
        weight.set("")
        hcm.set("")
    def bmic():
        try:
            a=weight.get()
            b=hcm.get()
            try:
                a1=int(a)
                b1=int(b)
                m=(b1/100)
                bmi1=a1/(m**2)
                if bmi1>=30.00:
                    messagebox.showinfo(title="Report", message=f"Your BMI is: {bmi1} \n This is considered Obese")
                elif 18.50<=bmi1<=24.99:
                    messagebox.showinfo(title="Report", message=f"Your BMI is: {bmi1} \n This is considered Normal")
                elif 25.00<=bmi1<=29.99:
                    messagebox.showinfo(title="Report", message=f"Your BMI is: {bmi1} \n This is considered Overweight")
                elif bmi1 >= 18.50:
                    messagebox.showinfo(title="Report", message=f"Your BMI is: {bmi1} \n This is considered Underweight")
            except:
                print(bmi1)
        except:
            messagebox.showinfo(title="Error", message="Enter only a valid number")
    exitb=Button(bmiw,text="Exit", command=delete).place(x=150,y=210)
    exitc=Button(bmiw,text="Calculate", command=bmic).place(x=135,y=180)
    bmiw.mainloop()
def AboutUs():
    os.startfile()("files//about.txt",os.O_RDWR)
def Contact():
    os.startfile("files//contact.txt",os.O_RDWR)
b1=Button(text="BM1 Calculator",command=bmi,borderwidth=3,relief=RAISED)
b1.place(x=200, y=100,width=100,height=70)
b4=Button(text="About Us",command=AboutUs,borderwidth=3,relief=RAISED)
b4.place(x=200, y=230,width=100,height=70)
b5=Button(text="Contact Us",borderwidth=3,command=Contact,relief=RAISED)
b5.place(x=200, y=350,width=100,height=70)
tk.mainloop()